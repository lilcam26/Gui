
function setup() {

  createCanvas(400, 400);
  background(245);
  fill(80);
  ellipse(200,200,400,400);
  fill(255,10,10);
  stroke(10);
  textSize(40);
  text('My App',130,75);
  star(5,30);

    
   One = createButton('Exercise 1');
    One.position(50 ,100 );
    One.size(85,40);
    One.mousePressed(ExerciseOne);
  
}

function draw() {
  

}

function star(startValX, startValY){
 var xValue = this.xValue;
  var yValue = this.yValue;
  
  stroke(126);
  line(xValue,yValue,xValue+ 5,yValue+15);
  line(xValue+5,yValue + 15,xValue + 10,30);
}

function ExerciseOne(){
  createCanvas(400, 400);
  
  
}


